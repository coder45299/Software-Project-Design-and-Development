"""Pick 10 real photos per demo pet from YOUR dataset and write photos/ + photos.js.

Usage:  python assign_photos.py path/to/dataset.zip      (or an extracted folder)
Dataset files are named like cat1.jpg, dog57.jpg, parrot12.jpg (any sub-folders are fine).
animals.ods / birds.ods (in ml/) are used to prefer photos where the face is clearly visible.
"""
import sys, os, re, json, shutil, zipfile, tempfile, random, collections
PER_PET = 10
# pet_id -> species word in the dataset file name.   (Coco the rabbit: dataset has no rabbit photos)
PETS = {1: ("Bruno", "dog"), 2: ("Luna", "cat"), 3: ("Max", "dog"), 4: ("Milo", "cat"),
        5: ("Coco", "rabbit"), 6: ("Kiwi", "parrot"), 7: ("Daisy", "dog"), 8: ("Oreo", "cat")}
EXT = {".jpg", ".jpeg", ".png", ".webp"}

def good_names():
    """File names whose feature list mentions eyes+nose/beak -> clear face."""
    good = set()
    try:
        import pandas as pd
        for f in ("ml/animals.ods", "ml/birds.ods"):
            d = pd.read_excel(f, engine="odf")
            for n, feat in zip(d.iloc[:, 0], d.iloc[:, 1]):
                s = str(feat).lower()
                if "eye" in s and ("nose" in s or "beak" in s): good.add(str(n).lower())
    except Exception as e:
        print("(skipping feature filter:", e, ")")
    return good

def main(src):
    tmp = None
    if os.path.isfile(src) and src.endswith(".zip"):
        tmp = tempfile.mkdtemp(); zipfile.ZipFile(src).extractall(tmp); src = tmp
    by = collections.defaultdict(list)
    for dp, _, fs in os.walk(src):
        for f in fs:
            if os.path.splitext(f)[1].lower() in EXT:
                m = re.match(r"([a-z]+)", f.lower())
                parts = [m.group(1)] if m else []
                parts += [p.lower() for p in os.path.relpath(dp, src).split(os.sep)]
                for sp in {p for _, s in PETS.values() for p in (s,)}:
                    if any(sp in p for p in parts): by[sp].append(os.path.join(dp, f)); break
    good, rng = good_names(), random.Random(7)
    for sp in by:
        by[sp].sort(); rng.shuffle(by[sp])
        by[sp].sort(key=lambda p: os.path.basename(p).lower() not in good)   # clear faces first (stable)
    print({k: len(v) for k, v in by.items()})
    shutil.rmtree("photos", ignore_errors=True); out = {}
    used = collections.defaultdict(int)
    for pid, (name, sp) in PETS.items():
        pool = by.get(sp, [])
        if len(pool) < used[sp] + PER_PET:
            print(f"!! {name} ({sp}): not enough photos in dataset -> keeping emoji"); continue
        chosen = pool[used[sp]:used[sp] + PER_PET]; used[sp] += PER_PET
        os.makedirs(f"photos/{pid}", exist_ok=True); out[pid] = []
        for i, p in enumerate(chosen, 1):
            dst = f"photos/{pid}/{i:02d}{os.path.splitext(p)[1].lower()}"; shutil.copy(p, dst); out[pid].append(dst)
        print(f"{name:6s} <- {PER_PET} x {sp}")
    open("photos.js", "w").write("window.PHOTOS = " + json.dumps(out, indent=1) + ";\n")
    if tmp: shutil.rmtree(tmp)

if __name__ == "__main__":
    if len(sys.argv) < 2: sys.exit(__doc__)
    main(sys.argv[1])
