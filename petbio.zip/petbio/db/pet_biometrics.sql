-- =====================================================================
--  Pet Biometrics - MySQL database
--  Run in phpMyAdmin (Import / SQL tab) or:  mysql -u root -p < database.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS pet_biometrics
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pet_biometrics;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS notifications, lost_reports, adoption_requests, adoption_posts,
                     care_records, pet_images, pets, users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- 1. users
-- ---------------------------------------------------------------------
CREATE TABLE users (
  user_id       INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100)  NOT NULL,
  email         VARCHAR(150)  NOT NULL UNIQUE,
  password_hash VARCHAR(255)  NOT NULL,              -- use PHP password_hash()
  phone         VARCHAR(20)   NULL,
  role          ENUM('user','admin') NOT NULL DEFAULT 'user',
  address       VARCHAR(255)  NULL,
  created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_users_role (role)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. pets
-- ---------------------------------------------------------------------
CREATE TABLE pets (
  pet_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_id    INT UNSIGNED NOT NULL,
  name        VARCHAR(100) NOT NULL,
  species     ENUM('Dog','Cat','Bird','Rabbit','Other') NOT NULL DEFAULT 'Dog',
  breed       VARCHAR(100) NULL,
  age         DECIMAL(4,1) NULL,
  gender      ENUM('Male','Female') NOT NULL DEFAULT 'Male',
  color       VARCHAR(60)  NULL,
  description TEXT         NULL,
  status      ENUM('owned','adoption','lost','adopted') NOT NULL DEFAULT 'owned',
  location    VARCHAR(120) NULL,                      -- used by frontend filters
  created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pets_owner FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_pets_status (status),
  INDEX idx_pets_species (species),
  INDEX idx_pets_location (location)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 3. pet_images  (embedding_vector is filled by the Python ML service)
-- ---------------------------------------------------------------------
CREATE TABLE pet_images (
  image_id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pet_id           INT UNSIGNED NOT NULL,
  image_path       VARCHAR(255) NOT NULL,
  is_primary       TINYINT(1)   NOT NULL DEFAULT 0,
  embedding_vector LONGTEXT     NULL,                 -- JSON array of floats
  uploaded_at      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_img_pet FOREIGN KEY (pet_id) REFERENCES pets(pet_id) ON DELETE CASCADE,
  INDEX idx_img_pet (pet_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4. care_records
-- ---------------------------------------------------------------------
CREATE TABLE care_records (
  record_id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pet_id        INT UNSIGNED NOT NULL,
  type          ENUM('Vaccination','Deworming','Vet Checkup','Grooming','Medication','Other') NOT NULL,
  date          DATE NOT NULL,
  notes         TEXT NULL,
  next_due_date DATE NULL,
  CONSTRAINT fk_care_pet FOREIGN KEY (pet_id) REFERENCES pets(pet_id) ON DELETE CASCADE,
  INDEX idx_care_due (next_due_date),
  INDEX idx_care_pet (pet_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 5. adoption_posts
-- ---------------------------------------------------------------------
CREATE TABLE adoption_posts (
  post_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pet_id     INT UNSIGNED NOT NULL,
  posted_by  INT UNSIGNED NOT NULL,
  location   VARCHAR(120) NOT NULL,
  note       TEXT NULL,
  status     ENUM('pending','active','adopted','rejected') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_post_pet  FOREIGN KEY (pet_id)    REFERENCES pets(pet_id)   ON DELETE CASCADE,
  CONSTRAINT fk_post_user FOREIGN KEY (posted_by) REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_post_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 6. adoption_requests
-- ---------------------------------------------------------------------
CREATE TABLE adoption_requests (
  request_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  post_id      INT UNSIGNED NOT NULL,
  requester_id INT UNSIGNED NOT NULL,
  phone        VARCHAR(20) NULL,
  message      TEXT NOT NULL,
  status       ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  date         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_req_post FOREIGN KEY (post_id)      REFERENCES adoption_posts(post_id) ON DELETE CASCADE,
  CONSTRAINT fk_req_user FOREIGN KEY (requester_id) REFERENCES users(user_id)          ON DELETE CASCADE,
  UNIQUE KEY uq_one_request (post_id, requester_id),
  INDEX idx_req_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 7. lost_reports  (found-pet reports; match filled after ML search)
-- ---------------------------------------------------------------------
CREATE TABLE lost_reports (
  report_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reporter_id    INT UNSIGNED NOT NULL,
  image_path     VARCHAR(255) NOT NULL,
  species        ENUM('Dog','Cat','Bird','Rabbit','Other') NOT NULL DEFAULT 'Dog',
  description    TEXT NULL,
  phone          VARCHAR(20) NULL,
  location       VARCHAR(255) NOT NULL,
  found_date     DATE NOT NULL,
  matched_pet_id INT UNSIGNED NULL,
  match_score    DECIMAL(5,2) NULL,                   -- 0 - 100
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_lost_user FOREIGN KEY (reporter_id)    REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_lost_pet  FOREIGN KEY (matched_pet_id) REFERENCES pets(pet_id)   ON DELETE SET NULL,
  INDEX idx_lost_date (found_date)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 8. notifications
-- ---------------------------------------------------------------------
CREATE TABLE notifications (
  notif_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  type       ENUM('match','adoption','care','system') NOT NULL DEFAULT 'system',
  message    VARCHAR(500) NOT NULL,
  is_read    TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_notif_user_read (user_id, is_read)
) ENGINE=InnoDB;

-- =====================================================================
--  Useful views
-- =====================================================================
CREATE OR REPLACE VIEW v_adoptable_pets AS
SELECT p.*, u.name AS owner_name, u.phone AS owner_phone,
       (SELECT image_path FROM pet_images i WHERE i.pet_id = p.pet_id
         ORDER BY i.is_primary DESC, i.image_id ASC LIMIT 1) AS cover_image
FROM pets p
JOIN users u ON u.user_id = p.owner_id
WHERE p.status = 'adoption';

CREATE OR REPLACE VIEW v_upcoming_care AS
SELECT c.*, p.name AS pet_name, p.owner_id,
       DATEDIFF(c.next_due_date, CURDATE()) AS days_left
FROM care_records c
JOIN pets p ON p.pet_id = c.pet_id
WHERE c.next_due_date IS NOT NULL;

-- =====================================================================
--  Auto-notify owner when a care record is due soon (daily event)
--  Needs:  SET GLOBAL event_scheduler = ON;
-- =====================================================================
DELIMITER $$
CREATE EVENT IF NOT EXISTS ev_care_reminders
ON SCHEDULE EVERY 1 DAY STARTS (CURRENT_DATE + INTERVAL 1 DAY + INTERVAL 8 HOUR)
DO
BEGIN
  INSERT INTO notifications (user_id, type, message)
  SELECT v.owner_id, 'care',
         CONCAT(v.pet_name, '''s ', LOWER(v.type), ' is due in ', v.days_left, ' day(s).')
  FROM v_upcoming_care v
  WHERE v.days_left BETWEEN 0 AND 3
    AND NOT EXISTS (
      SELECT 1 FROM notifications n
      WHERE n.user_id = v.owner_id AND n.type = 'care'
        AND n.message = CONCAT(v.pet_name, '''s ', LOWER(v.type), ' is due in ', v.days_left, ' day(s).')
        AND DATE(n.created_at) = CURDATE()
    );
END$$
DELIMITER ;

-- =====================================================================
--  Seed data (demo)
--  IMPORTANT: replace the password hash below. Generate one in PHP:
--     echo password_hash('admin123', PASSWORD_DEFAULT);
-- =====================================================================
INSERT INTO users (name, email, password_hash, phone, role, address) VALUES
 ('Admin',        'admin@petbio.com', 'REPLACE_WITH_PHP_PASSWORD_HASH', '01700000005', 'admin', 'Dhaka'),
 ('Demo User',    'demo@petbio.com',  'REPLACE_WITH_PHP_PASSWORD_HASH', '01700000001', 'user',  'Dhaka'),
 ('Rahim Uddin',  'rahim@mail.com',   'REPLACE_WITH_PHP_PASSWORD_HASH', '01700000002', 'user',  'Chattogram'),
 ('Nadia Karim',  'nadia@mail.com',   'REPLACE_WITH_PHP_PASSWORD_HASH', '01700000003', 'user',  'Dhaka'),
 ('Tanvir Hasan', 'tanvir@mail.com',  'REPLACE_WITH_PHP_PASSWORD_HASH', '01700000004', 'user',  'Khulna');

INSERT INTO pets (pet_id, owner_id, name, species, breed, age, gender, color, description, status, location) VALUES
 (1,2,'Bruno','Dog','Labrador',3,'Male','Golden','Playful and gentle Labrador who loves fetch. Fully vaccinated and great with children.','adoption','Dhaka'),
 (2,2,'Luna','Cat','Persian',2,'Female','White','Calm and affectionate Persian cat with blue eyes.','owned','Dhaka'),
 (3,3,'Max','Dog','German Shepherd',4,'Male','Black & Tan','Loyal and intelligent, looking for an active family with a yard.','adoption','Chattogram'),
 (4,3,'Milo','Cat','Tabby',1,'Male','Orange','Curious kitten full of energy, litter trained.','adoption','Sylhet'),
 (6,4,'Kiwi','Bird','Parrot',5,'Female','Green','Talkative green parrot, went missing near the central park.','lost','Rajshahi'),
 (7,5,'Daisy','Dog','Beagle',2,'Female','Tricolor','Friendly beagle that needs daily exercise.','adoption','Khulna'),
 (8,5,'Oreo','Cat','Siamese',3,'Male','Cream & Brown','Vocal and social Siamese cat.','adoption','Chattogram');

INSERT INTO care_records (pet_id, type, date, notes, next_due_date) VALUES
 (1,'Vaccination','2026-07-10','Rabies booster','2026-10-25'),
 (2,'Deworming','2026-09-02','Monthly tablet','2026-10-20'),
 (2,'Vet Checkup','2026-06-15','All healthy','2026-12-15'),
 (1,'Grooming','2026-09-28','Bath and nail trim','2026-10-12');

INSERT INTO adoption_posts (pet_id, posted_by, location, note, status) VALUES
 (1,2,'Dhaka','Moving abroad, need a loving home.','active'),
 (3,3,'Chattogram','Cannot keep due to space.','active'),
 (4,3,'Sylhet','Found as a stray, now healthy.','active'),
 (7,5,'Khulna','Looking for an active owner.','active'),
 (8,5,'Chattogram','Too many pets at home.','active');

INSERT INTO adoption_requests (post_id, requester_id, phone, message, status) VALUES
 (1,3,'01700000003','I have a big garden and two kids who would love Bruno.','pending'),
 (2,4,'01700000004','Experienced with German Shepherds, very interested.','approved');

INSERT INTO lost_reports (reporter_id, image_path, species, description, phone, location, found_date, matched_pet_id, match_score) VALUES
 (4,'uploads/lost/sample1.jpg','Dog','Small white and brown puppy near the lake, red collar.','01700000003','Dhanmondi Lake, Dhaka','2026-10-15',7,88.00),
 (5,'uploads/lost/sample2.jpg','Cat','Orange cat, very friendly.','01700000004','GEC Circle, Chattogram','2026-10-14',4,93.00),
 (2,'uploads/lost/sample3.jpg','Bird','Green parrot sitting on a tea stall roof.','01700000001','Zindabazar, Sylhet','2026-10-12',NULL,NULL);

INSERT INTO notifications (user_id, type, message, is_read) VALUES
 (2,'match','A possible match was found for your lost pet Kiwi (91% similarity).',0),
 (2,'adoption','Rahim Uddin sent an adoption request for Bruno.',0),
 (2,'care','Luna''s deworming is due in 3 days.',0),
 (2,'system','Welcome to Pet Biometrics! Add your first pet to get started.',1);

-- Note: the seed owner ids differ from the frontend demo (Demo User is user_id 2 here, Admin is 1).
