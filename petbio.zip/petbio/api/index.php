<?php
declare(strict_types=1);
/**
 * Pet Biometrics - REST API (PHP 8+, PDO/MySQL)
 * Single entry point. All routes are relative to /api
 */
// ======================= SETTINGS (edit these) =======================
$cfg = [
    'db' => ['host' => '127.0.0.1', 'name' => 'pet_biometrics', 'user' => 'root', 'pass' => '', 'charset' => 'utf8mb4'],
    'allowed_origin' => '',                    // only if frontend is on another origin, e.g. 'http://localhost:5500'
    'upload_dir' => __DIR__ . '/../uploads',   // created automatically
    'upload_url' => 'uploads',                 // path saved in DB
    'max_upload_mb' => 5,
    'ml_url' => 'http://127.0.0.1:5000',       // Python ML service
    'match_threshold' => 50,                   // min similarity (0-100) to show a match
    'notify_threshold' => 70,                  // notify lost pet's owner at/above this
];
// =====================================================================


session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'path' => '/']);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// ---------- CORS (only when frontend is on another origin) ----------
if ($cfg['allowed_origin'] !== '') {
    header('Access-Control-Allow-Origin: ' . $cfg['allowed_origin']);
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Allow-Headers: Content-Type');
    header('Access-Control-Allow-Methods: GET,POST,DELETE,OPTIONS');
}
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

set_exception_handler(function (Throwable $e) {
    error_log('[PetBio] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    out(['message' => 'Server error. Please try again.'], 500);
});

// =====================================================================
//  Helpers
// =====================================================================
function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    global $cfg;
    $d = $cfg['db'];
    $pdo = new PDO("mysql:host={$d['host']};dbname={$d['name']};charset={$d['charset']}", $d['user'], $d['pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    return $pdo;
}
function out($data, int $code = 200): never {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function fail(string $msg, int $code = 400): never { out(['message' => $msg], $code); }

function body(): array {
    static $b = null;
    if ($b !== null) return $b;
    $ct = $_SERVER['CONTENT_TYPE'] ?? '';
    if (stripos($ct, 'application/json') !== false) {
        $j = json_decode(file_get_contents('php://input') ?: '', true);
        return $b = is_array($j) ? $j : [];
    }
    return $b = $_POST;
}
function str(string $key, int $max = 255, bool $required = false): string {
    $v = trim((string)(body()[$key] ?? ''));
    if ($required && $v === '') fail(ucfirst(str_replace('_', ' ', $key)) . ' is required.');
    return mb_substr($v, 0, $max);
}
function pick(string $key, array $allowed, string $default): string {
    $v = (string)(body()[$key] ?? $default);
    return in_array($v, $allowed, true) ? $v : $default;
}
function validDate(?string $d): bool {
    if (!$d) return false;
    $x = DateTime::createFromFormat('Y-m-d', $d);
    return $x && $x->format('Y-m-d') === $d;
}

const SPECIES = ['Dog', 'Cat', 'Bird', 'Rabbit', 'Other'];
const CARE_TYPES = ['Vaccination', 'Deworming', 'Vet Checkup', 'Grooming', 'Medication', 'Other'];

function me(): ?array {
    if (empty($_SESSION['uid'])) return null;
    static $u = false;
    if ($u === false) {
        $st = db()->prepare('SELECT user_id,name,email,phone,role,address,created_at FROM users WHERE user_id=?');
        $st->execute([$_SESSION['uid']]);
        $u = $st->fetch() ?: null;
        if (!$u) unset($_SESSION['uid']);
    }
    return $u;
}
function needLogin(): array { return me() ?? fail('Please login first.', 401); }
function needAdmin(): array { $u = needLogin(); if ($u['role'] !== 'admin') fail('Admin access only.', 403); return $u; }

function notify(int $uid, string $type, string $msg): void {
    db()->prepare('INSERT INTO notifications (user_id,type,message) VALUES (?,?,?)')->execute([$uid, $type, mb_substr($msg, 0, 500)]);
}

// ---------- uploads ----------
function filesList(string $key): array {
    if (empty($_FILES[$key])) return [];
    $f = $_FILES[$key];
    if (!is_array($f['name'])) return $f['error'] === UPLOAD_ERR_NO_FILE ? [] : [$f];
    $o = [];
    foreach ($f['name'] as $i => $n) {
        if ($f['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
        $o[] = ['name' => $n, 'type' => $f['type'][$i], 'tmp_name' => $f['tmp_name'][$i], 'error' => $f['error'][$i], 'size' => $f['size'][$i]];
    }
    return $o;
}
function saveImage(array $f, string $sub): string {
    global $cfg;
    if ($f['error'] !== UPLOAD_ERR_OK) fail('Image upload failed.');
    if ($f['size'] > $cfg['max_upload_mb'] * 1048576) fail('Image is too large (max ' . $cfg['max_upload_mb'] . 'MB).', 413);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
    if (!$ext) fail('Only JPG, PNG or WEBP images are allowed.', 415);
    $dir = $cfg['upload_dir'] . '/' . $sub;
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $name = bin2hex(random_bytes(12)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], "$dir/$name")) fail('Could not save image.', 500);
    return $cfg['upload_url'] . "/$sub/$name";
}
function absPath(string $rel): string {
    global $cfg;
    return $cfg['upload_dir'] . '/' . substr($rel, strlen($cfg['upload_url']) + 1);
}
function deleteImageFile(string $rel): void { $p = absPath($rel); if (is_file($p)) @unlink($p); }

// ---------- ML service ----------
function embed(string $file): ?array {
    global $cfg;
    if (!function_exists('curl_init')) return null;
    $ch = curl_init(rtrim($cfg['ml_url'], '/') . '/embed');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => ['image' => new CURLFile($file)],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_TIMEOUT => 30,
    ]);
    $r = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($r === false || $code !== 200) return null;
    $j = json_decode($r, true);
    return (isset($j['embedding']) && is_array($j['embedding'])) ? array_map('floatval', $j['embedding']) : null;
}
function cosine(array $a, array $b): float {
    $dot = $na = $nb = 0.0;
    foreach ($a as $i => $x) { $y = $b[$i]; $dot += $x * $y; $na += $x * $x; $nb += $y * $y; }
    return ($na > 0 && $nb > 0) ? $dot / (sqrt($na) * sqrt($nb)) : 0.0;
}
/** Compare an embedding with every stored pet image. Returns [['pet_id'=>..,'score'=>0-100], ...] best first. */
function findMatches(array $vec, ?string $species, int $limit = 5): array {
    global $cfg;
    $sql = 'SELECT i.pet_id, i.embedding_vector FROM pet_images i JOIN pets p ON p.pet_id=i.pet_id WHERE i.embedding_vector IS NOT NULL';
    $args = [];
    if ($species && in_array($species, SPECIES, true)) { $sql .= ' AND p.species=?'; $args[] = $species; }
    $st = db()->prepare($sql);
    $st->execute($args);
    $best = [];
    foreach ($st as $row) {
        $v = json_decode($row['embedding_vector'], true);
        if (!is_array($v) || count($v) !== count($vec)) continue;
        $s = cosine($vec, $v);
        $pid = (int)$row['pet_id'];
        if (!isset($best[$pid]) || $s > $best[$pid]) $best[$pid] = $s;
    }
    arsort($best);
    $res = [];
    foreach (array_slice($best, 0, $limit, true) as $pid => $s) {
        $score = round(max(0, $s) * 100, 1);
        if ($score >= $cfg['match_threshold']) $res[] = ['pet_id' => $pid, 'score' => $score];
    }
    return $res;
}

// ---------- formatting ----------
function fmtPet(array $p): array {
    $p['pet_id'] = (int)$p['pet_id'];
    $p['owner_id'] = (int)$p['owner_id'];
    $p['age'] = $p['age'] !== null ? (float)$p['age'] : null;
    return $p;
}
const COVER_SQL = '(SELECT image_path FROM pet_images i WHERE i.pet_id=p.pet_id ORDER BY i.is_primary DESC, i.image_id ASC LIMIT 1) AS cover_image';

function petRow(int $id): ?array {
    $st = db()->prepare('SELECT p.*, u.name AS owner_name, ' . COVER_SQL . ' FROM pets p JOIN users u ON u.user_id=p.owner_id WHERE p.pet_id=?');
    $st->execute([$id]);
    $r = $st->fetch();
    return $r ? fmtPet($r) : null;
}
function reportRow(int $id): array {
    $st = db()->prepare('SELECT r.*, u.name AS reporter, p.name AS matched_pet FROM lost_reports r JOIN users u ON u.user_id=r.reporter_id LEFT JOIN pets p ON p.pet_id=r.matched_pet_id WHERE r.report_id=?');
    $st->execute([$id]);
    return fmtReport($st->fetch());
}
function fmtReport(array $r): array {
    $r['report_id'] = (int)$r['report_id'];
    $r['matched_pet_id'] = $r['matched_pet_id'] !== null ? (int)$r['matched_pet_id'] : null;
    $r['match_score'] = $r['match_score'] !== null ? (float)$r['match_score'] : null;
    unset($r['reporter_id']);
    return $r;
}

// =====================================================================
//  Router
// =====================================================================
$path = trim((string)parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$base = trim(dirname($_SERVER['SCRIPT_NAME']), '/\\.');
if ($base !== '' && str_starts_with($path, $base)) $path = trim(substr($path, strlen($base)), '/');
if (str_starts_with($path, 'index.php')) $path = trim(substr($path, 9), '/');
// Fallback that needs no URL rewriting at all:  api/index.php?route=/pets/5
if ($path === '' && isset($_GET['route'])) $path = trim((string)$_GET['route'], '/');
$seg = $path === '' ? [] : explode('/', $path);
$method = $_SERVER['REQUEST_METHOD'];

switch ($seg[0] ?? '') {
    case '':              out(['name' => 'Pet Biometrics API', 'status' => 'ok']);
    case 'auth':          routeAuth($seg, $method); break;
    case 'pets':          routePets($seg, $method); break;
    case 'adoption':      routeAdoption($seg, $method); break;
    case 'care':          routeCare($seg, $method); break;
    case 'find-pet':      routeFindPet($method); break;
    case 'lost-reports':  routeLost($seg, $method); break;
    case 'notifications': routeNotifs($seg, $method); break;
    case 'admin':         routeAdmin($seg, $method); break;
    default:              fail('Not found.', 404);
}
fail('Method not allowed.', 405);

// =====================================================================
//  AUTH
// =====================================================================
function routeAuth(array $seg, string $m): void {
    $a = $seg[1] ?? '';
    if ($a === 'register' && $m === 'POST') {
        $name = str('name', 100, true); $email = strtolower(str('email', 150, true));
        $pass = (string)(body()['password'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Enter a valid email address.');
        if (strlen($pass) < 6) fail('Password must be at least 6 characters.');
        $phone = str('phone', 20);
        if ($phone !== '' && !preg_match('/^[0-9+\-\s]{6,20}$/', $phone)) fail('Enter a valid phone number.');
        $st = db()->prepare('SELECT 1 FROM users WHERE email=?'); $st->execute([$email]);
        if ($st->fetch()) fail('This email is already registered.', 409);
        db()->prepare('INSERT INTO users (name,email,password_hash,phone,address) VALUES (?,?,?,?,?)')
            ->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT), $phone ?: null, str('address') ?: null]);
        $id = (int)db()->lastInsertId();
        notify($id, 'system', 'Welcome to Pet Biometrics! Add your first pet to get started.');
        session_regenerate_id(true);
        $_SESSION['uid'] = $id;
        out(['user' => me()], 201);
    }
    if ($a === 'login' && $m === 'POST') {
        if (($_SESSION['tries'] ?? 0) >= 5 && time() - ($_SESSION['try_time'] ?? 0) < 300) fail('Too many attempts. Try again in a few minutes.', 429);
        $email = strtolower(str('email', 150, true)); $pass = (string)(body()['password'] ?? '');
        $st = db()->prepare('SELECT * FROM users WHERE email=?'); $st->execute([$email]);
        $u = $st->fetch();
        if (!$u || !password_verify($pass, $u['password_hash'])) {
            $_SESSION['tries'] = ($_SESSION['tries'] ?? 0) + 1; $_SESSION['try_time'] = time();
            fail('Incorrect email or password.', 401);
        }
        session_regenerate_id(true);
        $_SESSION = ['uid' => (int)$u['user_id']];
        unset($u['password_hash']);
        out(['user' => $u]);
    }
    if ($a === 'me' && $m === 'GET') out(['user' => me()]);
    if ($a === 'logout' && $m === 'POST') { $_SESSION = []; session_destroy(); out(['ok' => true]); }
    fail('Not found.', 404);
}

// =====================================================================
//  PETS
// =====================================================================
function routePets(array $seg, string $m): void {
    $id = $seg[1] ?? '';

    if ($id === '' && $m === 'GET') {              // list (public)
        $sql = 'SELECT p.*, ' . COVER_SQL . ' FROM pets p WHERE 1=1'; $args = [];
        if (!empty($_GET['status']))  { $sql .= ' AND p.status=?';  $args[] = $_GET['status']; }
        if (!empty($_GET['species'])) { $sql .= ' AND p.species=?'; $args[] = $_GET['species']; }
        if (!empty($_GET['q']))       { $sql .= ' AND (p.name LIKE ? OR p.breed LIKE ?)'; $args[] = '%' . $_GET['q'] . '%'; $args[] = '%' . $_GET['q'] . '%'; }
        $sql .= ' ORDER BY p.created_at DESC LIMIT ' . max(1, min(100, (int)($_GET['limit'] ?? 50)));
        $st = db()->prepare($sql); $st->execute($args);
        out(['data' => array_map('fmtPet', $st->fetchAll())]);
    }
    if ($id === 'mine' && $m === 'GET') {          // my pets
        $u = needLogin();
        $st = db()->prepare('SELECT p.*, ' . COVER_SQL . ' FROM pets p WHERE p.owner_id=? ORDER BY p.created_at DESC');
        $st->execute([$u['user_id']]);
        out(['data' => array_map('fmtPet', $st->fetchAll())]);
    }
    if ($id === '' && $m === 'POST') { savePet(null); }

    if (ctype_digit($id)) {
        $pid = (int)$id;
        if ($m === 'GET') {
            $p = petRow($pid) ?? fail('Pet not found.', 404);
            $st = db()->prepare('SELECT image_id,image_path,is_primary FROM pet_images WHERE pet_id=? ORDER BY is_primary DESC,image_id');
            $st->execute([$pid]);
            $p['images'] = $st->fetchAll();
            out(['data' => $p]);
        }
        if ($m === 'POST') savePet($pid);
        if ($m === 'DELETE') {
            $u = needLogin(); $p = petRow($pid) ?? fail('Pet not found.', 404);
            if ($p['owner_id'] !== (int)$u['user_id'] && $u['role'] !== 'admin') fail('Not allowed.', 403);
            $st = db()->prepare('SELECT image_path FROM pet_images WHERE pet_id=?'); $st->execute([$pid]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $img) deleteImageFile($img);
            db()->prepare('DELETE FROM pets WHERE pet_id=?')->execute([$pid]);
            out(['ok' => true]);
        }
    }
    fail('Not found.', 404);
}

function savePet(?int $pid): never {
    $u = needLogin();
    $name = str('name', 100, true);
    $species = pick('species', SPECIES, 'Dog');
    $gender = pick('gender', ['Male', 'Female'], 'Male');
    $status = pick('status', ['owned', 'adoption', 'lost'], 'owned');
    $age = body()['age'] ?? null; $age = ($age === '' || $age === null) ? null : max(0, min(40, (float)$age));
    $vals = [$name, $species, str('breed', 100) ?: null, $age, $gender, str('color', 60) ?: null, str('description', 5000) ?: null, $status, str('location', 120) ?: null];

    if ($pid === null) {
        db()->prepare('INSERT INTO pets (owner_id,name,species,breed,age,gender,color,description,status,location) VALUES (?,?,?,?,?,?,?,?,?,?)')
            ->execute([$u['user_id'], ...$vals]);
        $pid = (int)db()->lastInsertId();
    } else {
        $p = petRow($pid) ?? fail('Pet not found.', 404);
        if ($p['owner_id'] !== (int)$u['user_id'] && $u['role'] !== 'admin') fail('Not allowed.', 403);
        db()->prepare('UPDATE pets SET name=?,species=?,breed=?,age=?,gender=?,color=?,description=?,status=?,location=? WHERE pet_id=?')
            ->execute([...$vals, $pid]);
    }

    // new photos (first one becomes primary if the pet has none)
    $files = filesList('images');
    if (count($files) > 6) fail('Maximum 6 photos allowed.');
    $st = db()->prepare('SELECT COUNT(*) FROM pet_images WHERE pet_id=?'); $st->execute([$pid]);
    $has = (int)$st->fetchColumn();
    foreach ($files as $i => $f) {
        $path = saveImage($f, 'pets');
        $vec = embed(absPath($path));            // null if ML service is offline (can be back-filled later)
        db()->prepare('INSERT INTO pet_images (pet_id,image_path,is_primary,embedding_vector) VALUES (?,?,?,?)')
            ->execute([$pid, $path, ($has === 0 && $i === 0) ? 1 : 0, $vec ? json_encode($vec) : null]);
    }
    out(['data' => petRow($pid)], 201);
}

// =====================================================================
//  ADOPTION
// =====================================================================
function routeAdoption(array $seg, string $m): void {
    $a = $seg[1] ?? '';

    if ($a === '' && $m === 'GET') {               // public listing
        $sql = "SELECT p.*, " . COVER_SQL . " FROM pets p WHERE p.status='adoption'"; $args = [];
        foreach (['species', 'gender', 'location'] as $f) if (!empty($_GET[$f])) { $sql .= " AND p.$f=?"; $args[] = $_GET[$f]; }
        if (!empty($_GET['q'])) { $sql .= ' AND (p.name LIKE ? OR p.breed LIKE ?)'; $args[] = '%' . $_GET['q'] . '%'; $args[] = '%' . $_GET['q'] . '%'; }
        $st = db()->prepare($sql . ' ORDER BY p.created_at DESC'); $st->execute($args);
        out(['data' => array_map('fmtPet', $st->fetchAll())]);
    }

    if ($a === '' && $m === 'POST') {              // post my pet for adoption
        $u = needLogin();
        $p = petRow((int)(body()['pet_id'] ?? 0)) ?? fail('Pet not found.', 404);
        if ($p['owner_id'] !== (int)$u['user_id']) fail('You can only post your own pets.', 403);
        $loc = str('location', 120, true);
        db()->prepare("INSERT INTO adoption_posts (pet_id,posted_by,location,note,status) VALUES (?,?,?,?, 'active')")
            ->execute([$p['pet_id'], $u['user_id'], $loc, str('note', 2000) ?: null]);
        db()->prepare("UPDATE pets SET status='adoption', location=? WHERE pet_id=?")->execute([$loc, $p['pet_id']]);
        out(['ok' => true], 201);
    }

    if ($a === 'request' && $m === 'POST') {       // send adoption request
        $u = needLogin();
        $pid = (int)(body()['pet_id'] ?? 0);
        $st = db()->prepare("SELECT ap.post_id, ap.posted_by, p.name FROM adoption_posts ap JOIN pets p ON p.pet_id=ap.pet_id WHERE ap.pet_id=? AND ap.status='active' ORDER BY ap.post_id DESC LIMIT 1");
        $st->execute([$pid]);
        $post = $st->fetch() ?: fail('This pet is not available for adoption.', 404);
        if ((int)$post['posted_by'] === (int)$u['user_id']) fail('You cannot adopt your own pet.');
        $st = db()->prepare('SELECT 1 FROM adoption_requests WHERE post_id=? AND requester_id=?'); $st->execute([$post['post_id'], $u['user_id']]);
        if ($st->fetch()) fail('You already sent a request for this pet.', 409);
        db()->prepare('INSERT INTO adoption_requests (post_id,requester_id,phone,message) VALUES (?,?,?,?)')
            ->execute([$post['post_id'], $u['user_id'], str('phone', 20) ?: null, str('message', 2000, true)]);
        notify((int)$post['posted_by'], 'adoption', $u['name'] . ' sent an adoption request for ' . $post['name'] . '.');
        out(['ok' => true], 201);
    }

    if ($a === 'requests' && ($seg[2] ?? '') === '' && $m === 'GET') {   // requests on MY pets
        $u = needLogin();
        $st = db()->prepare('SELECT r.request_id, p.name AS pet, ru.name AS requester, r.phone, r.message, r.status, r.date
            FROM adoption_requests r JOIN adoption_posts ap ON ap.post_id=r.post_id JOIN pets p ON p.pet_id=ap.pet_id
            JOIN users ru ON ru.user_id=r.requester_id WHERE ap.posted_by=? ORDER BY r.date DESC');
        $st->execute([$u['user_id']]);
        out(['data' => $st->fetchAll()]);
    }

    if ($a === 'requests' && ctype_digit($seg[2] ?? '') && ($seg[3] ?? '') === 'decide' && $m === 'POST') {
        $u = needLogin(); $rid = (int)$seg[2];
        $status = pick('status', ['approved', 'rejected'], '');
        if ($status === '') fail('Status must be approved or rejected.');
        $st = db()->prepare('SELECT r.request_id, r.requester_id, r.status, ap.post_id, ap.pet_id, ap.posted_by, p.name FROM adoption_requests r
            JOIN adoption_posts ap ON ap.post_id=r.post_id JOIN pets p ON p.pet_id=ap.pet_id WHERE r.request_id=?');
        $st->execute([$rid]);
        $r = $st->fetch() ?: fail('Request not found.', 404);
        if ((int)$r['posted_by'] !== (int)$u['user_id'] && $u['role'] !== 'admin') fail('Not allowed.', 403);
        if ($r['status'] !== 'pending') fail('This request was already decided.');
        $pdo = db(); $pdo->beginTransaction();
        $pdo->prepare('UPDATE adoption_requests SET status=? WHERE request_id=?')->execute([$status, $rid]);
        if ($status === 'approved') {
            $pdo->prepare("UPDATE adoption_posts SET status='adopted' WHERE post_id=?")->execute([$r['post_id']]);
            $pdo->prepare("UPDATE pets SET status='adopted' WHERE pet_id=?")->execute([$r['pet_id']]);
            $pdo->prepare("UPDATE adoption_requests SET status='rejected' WHERE post_id=? AND request_id<>? AND status='pending'")->execute([$r['post_id'], $rid]);
        }
        $pdo->commit();
        notify((int)$r['requester_id'], 'adoption', 'Your adoption request for ' . $r['name'] . ' was ' . $status . '.');
        out(['ok' => true]);
    }
    fail('Not found.', 404);
}

// =====================================================================
//  CARE TRACKER
// =====================================================================
function ownPetOrFail(int $pid, array $u): array {
    $p = petRow($pid) ?? fail('Pet not found.', 404);
    if ($p['owner_id'] !== (int)$u['user_id'] && $u['role'] !== 'admin') fail('Not allowed.', 403);
    return $p;
}
function routeCare(array $seg, string $m): void {
    $u = needLogin(); $a = $seg[1] ?? '';

    if ($a === '' && $m === 'GET') {
        $pid = (int)($_GET['pet_id'] ?? 0); ownPetOrFail($pid, $u);
        $st = db()->prepare('SELECT * FROM care_records WHERE pet_id=? ORDER BY date DESC'); $st->execute([$pid]);
        out(['data' => $st->fetchAll()]);
    }
    if ($a === 'upcoming' && $m === 'GET') {       // for dashboard reminders
        $st = db()->prepare('SELECT c.*, p.name AS pet_name, DATEDIFF(c.next_due_date, CURDATE()) AS days_left
            FROM care_records c JOIN pets p ON p.pet_id=c.pet_id WHERE p.owner_id=? AND c.next_due_date IS NOT NULL
            ORDER BY c.next_due_date LIMIT 10');
        $st->execute([$u['user_id']]);
        out(['data' => $st->fetchAll()]);
    }
    if ($a === '' && $m === 'POST') {
        $pid = (int)(body()['pet_id'] ?? 0); ownPetOrFail($pid, $u);
        $date = str('date', 10, true); $next = str('next_due_date', 10);
        if (!validDate($date)) fail('Enter a valid date.');
        if ($next !== '' && !validDate($next)) fail('Enter a valid next due date.');
        db()->prepare('INSERT INTO care_records (pet_id,type,date,notes,next_due_date) VALUES (?,?,?,?,?)')
            ->execute([$pid, pick('type', CARE_TYPES, 'Other'), $date, str('notes', 2000) ?: null, $next ?: null]);
        out(['data' => ['record_id' => (int)db()->lastInsertId()]], 201);
    }
    if (ctype_digit($a) && $m === 'DELETE') {
        $st = db()->prepare('SELECT pet_id FROM care_records WHERE record_id=?'); $st->execute([$a]);
        $r = $st->fetch() ?: fail('Record not found.', 404);
        ownPetOrFail((int)$r['pet_id'], $u);
        db()->prepare('DELETE FROM care_records WHERE record_id=?')->execute([$a]);
        out(['ok' => true]);
    }
    fail('Not found.', 404);
}

// =====================================================================
//  FIND MY PET  (biometric matching)
// =====================================================================
function routeFindPet(string $m): void {
    if ($m !== 'POST') fail('Method not allowed.', 405);
    $files = filesList('image');
    if (!$files) fail('Please upload a photo.');
    $path = saveImage($files[0], 'tmp');
    try {
        $vec = embed(absPath($path));
        if (!$vec) fail('The matching service is unavailable right now. Please try again later.', 503);
        $matches = findMatches($vec, $_POST['species'] ?? null, 5);
        foreach ($matches as &$mt) $mt['pet'] = petRow($mt['pet_id']);
        unset($mt);
        out(['matches' => $matches]);
    } finally {
        deleteImageFile($path);                 // search photos are not kept
    }
}

// =====================================================================
//  LOST / FOUND REPORTS
// =====================================================================
function routeLost(array $seg, string $m): void {
    global $cfg;
    if (($seg[1] ?? '') === '' && $m === 'GET') {
        $st = db()->query('SELECT r.*, u.name AS reporter, p.name AS matched_pet FROM lost_reports r
            JOIN users u ON u.user_id=r.reporter_id LEFT JOIN pets p ON p.pet_id=r.matched_pet_id ORDER BY r.created_at DESC LIMIT 100');
        out(['data' => array_map('fmtReport', $st->fetchAll())]);
    }
    if (($seg[1] ?? '') === '' && $m === 'POST') {
        $u = needLogin();
        $files = filesList('image');
        if (!$files) fail('Please upload a photo of the pet.');
        $loc = str('location', 255, true); $date = str('found_date', 10, true);
        if (!validDate($date)) fail('Enter a valid date.');
        $species = pick('species', SPECIES, 'Dog');
        $path = saveImage($files[0], 'lost');

        $matchId = null; $score = null;
        if ($vec = embed(absPath($path))) {
            $best = findMatches($vec, $species, 1)[0] ?? null;
            if ($best) { $matchId = $best['pet_id']; $score = $best['score']; }
        }
        db()->prepare('INSERT INTO lost_reports (reporter_id,image_path,species,description,phone,location,found_date,matched_pet_id,match_score) VALUES (?,?,?,?,?,?,?,?,?)')
            ->execute([$u['user_id'], $path, $species, str('description', 2000) ?: null, str('phone', 20) ?: null, $loc, $date, $matchId, $score]);
        $rid = (int)db()->lastInsertId();

        if ($matchId && $score >= $cfg['notify_threshold']) {
            $p = petRow($matchId);
            if ($p && $p['status'] === 'lost') {
                notify($p['owner_id'], 'match', 'A possible match was found for your lost pet ' . $p['name'] . ' (' . round($score) . '% similarity) near ' . $loc . '.');
            }
        }
        out(['data' => reportRow($rid)], 201);
    }
    if (ctype_digit($seg[1] ?? '') && $m === 'DELETE') {
        $u = needLogin();
        $st = db()->prepare('SELECT reporter_id, image_path FROM lost_reports WHERE report_id=?'); $st->execute([$seg[1]]);
        $r = $st->fetch() ?: fail('Report not found.', 404);
        if ((int)$r['reporter_id'] !== (int)$u['user_id'] && $u['role'] !== 'admin') fail('Not allowed.', 403);
        deleteImageFile($r['image_path']);
        db()->prepare('DELETE FROM lost_reports WHERE report_id=?')->execute([$seg[1]]);
        out(['ok' => true]);
    }
    fail('Not found.', 404);
}

// =====================================================================
//  NOTIFICATIONS
// =====================================================================
function routeNotifs(array $seg, string $m): void {
    $u = needLogin(); $a = $seg[1] ?? '';
    if ($a === '' && $m === 'GET') {
        $st = db()->prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC, notif_id DESC LIMIT 100'); $st->execute([$u['user_id']]);
        $rows = $st->fetchAll();
        foreach ($rows as &$r) { $r['notif_id'] = (int)$r['notif_id']; $r['is_read'] = (int)$r['is_read']; }
        out(['data' => $rows, 'unread' => count(array_filter($rows, fn($r) => !$r['is_read']))]);
    }
    if ($a === 'read' && $m === 'POST') {          // body: {id} for one, nothing for all
        $id = (int)(body()['id'] ?? 0);
        if ($id) db()->prepare('UPDATE notifications SET is_read=1 WHERE notif_id=? AND user_id=?')->execute([$id, $u['user_id']]);
        else     db()->prepare('UPDATE notifications SET is_read=1 WHERE user_id=?')->execute([$u['user_id']]);
        out(['ok' => true]);
    }
    if (ctype_digit($a) && $m === 'DELETE') {
        db()->prepare('DELETE FROM notifications WHERE notif_id=? AND user_id=?')->execute([$a, $u['user_id']]);
        out(['ok' => true]);
    }
    fail('Not found.', 404);
}

// =====================================================================
//  ADMIN
// =====================================================================
function routeAdmin(array $seg, string $m): void {
    $me = needAdmin(); $a = $seg[1] ?? '';

    if ($a === 'stats' && $m === 'GET') {
        $c = fn(string $sql) => (int)db()->query($sql)->fetchColumn();
        out(['data' => [
            'users' => $c('SELECT COUNT(*) FROM users'), 'pets' => $c('SELECT COUNT(*) FROM pets'),
            'pending_requests' => $c("SELECT COUNT(*) FROM adoption_requests WHERE status='pending'"),
            'reports' => $c('SELECT COUNT(*) FROM lost_reports'),
            'by_species' => db()->query('SELECT species, COUNT(*) AS total FROM pets GROUP BY species')->fetchAll(),
        ]]);
    }
    if ($a === 'users' && ($seg[2] ?? '') === '' && $m === 'GET') {
        out(['data' => db()->query('SELECT user_id,name,email,phone,role,address,created_at FROM users ORDER BY user_id')->fetchAll()]);
    }
    if ($a === 'users' && ctype_digit($seg[2] ?? '')) {
        $uid = (int)$seg[2];
        if ($uid === (int)$me['user_id']) fail('You cannot change your own account here.');
        if (($seg[3] ?? '') === 'role' && $m === 'POST') {
            db()->prepare('UPDATE users SET role=? WHERE user_id=?')->execute([pick('role', ['user', 'admin'], 'user'), $uid]);
            out(['ok' => true]);
        }
        if ($m === 'DELETE') { db()->prepare('DELETE FROM users WHERE user_id=?')->execute([$uid]); out(['ok' => true]); }
    }
    if ($a === 'requests' && $m === 'GET') {
        out(['data' => db()->query('SELECT r.request_id, p.name AS pet, u.name AS requester, r.message, r.status, r.date
            FROM adoption_requests r JOIN adoption_posts ap ON ap.post_id=r.post_id JOIN pets p ON p.pet_id=ap.pet_id
            JOIN users u ON u.user_id=r.requester_id ORDER BY r.date DESC')->fetchAll()]);
    }
    fail('Not found.', 404);
}