/* =========================================================
   Pet Biometrics - shared frontend script
   ---------------------------------------------------------
   CONFIG.USE_DEMO = true  -> runs fully in the browser with demo data
   CONFIG.USE_DEMO = false -> pages call the PHP backend (API_BASE)
   ========================================================= */
const CONFIG = { API_BASE: '/api/index.php', USE_DEMO: true };

const EMOJI = { Dog: '🐶', Cat: '🐱', Bird: '🦜', Rabbit: '🐰', Other: '🐾' };
const GRAD = [
  'linear-gradient(135deg,#99f6e4,#5eead4)', 'linear-gradient(135deg,#fed7aa,#fdba74)',
  'linear-gradient(135deg,#bfdbfe,#93c5fd)', 'linear-gradient(135deg,#fbcfe8,#f9a8d4)',
  'linear-gradient(135deg,#ddd6fe,#c4b5fd)', 'linear-gradient(135deg,#fde68a,#fcd34d)'
];
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const Store = {
  get(k, d) { try { const v = localStorage.getItem('pb_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { localStorage.setItem('pb_' + k, JSON.stringify(v)); },
  del(k) { localStorage.removeItem('pb_' + k); }
};

/* ---------- Demo data (mirrors the MySQL tables) ---------- */
const DEMO = {
  pets: [
    { pet_id: 1, owner_id: 1, name: 'Bruno', species: 'Dog', breed: 'Labrador', age: 3, gender: 'Male', color: 'Golden', status: 'adoption', location: 'Dhaka', description: 'Bruno is a playful and gentle Labrador who loves fetch and long walks. Fully vaccinated, house-trained and great with children.' },
    { pet_id: 2, owner_id: 1, name: 'Luna', species: 'Cat', breed: 'Persian', age: 2, gender: 'Female', color: 'White', status: 'owned', location: 'Dhaka', description: 'Calm and affectionate Persian cat with striking blue eyes. Loves sunny windows and soft blankets.' },
    { pet_id: 3, owner_id: 2, name: 'Max', species: 'Dog', breed: 'German Shepherd', age: 4, gender: 'Male', color: 'Black & Tan', status: 'adoption', location: 'Chattogram', description: 'Loyal and intelligent. Max knows basic commands and is looking for an active family with a yard.' },
    { pet_id: 4, owner_id: 2, name: 'Milo', species: 'Cat', breed: 'Tabby', age: 1, gender: 'Male', color: 'Orange', status: 'adoption', location: 'Sylhet', description: 'Curious kitten full of energy. Litter trained and gets along well with other cats.' },
    { pet_id: 6, owner_id: 3, name: 'Kiwi', species: 'Bird', breed: 'Parrot', age: 5, gender: 'Female', color: 'Green', status: 'lost', location: 'Rajshahi', description: 'Talkative green parrot, can whistle and say a few words. Went missing near the central park.' },
    { pet_id: 7, owner_id: 4, name: 'Daisy', species: 'Dog', breed: 'Beagle', age: 2, gender: 'Female', color: 'Tricolor', status: 'adoption', location: 'Khulna', description: 'Friendly beagle with a great nose. Needs daily exercise and lots of love.' },
    { pet_id: 8, owner_id: 4, name: 'Oreo', species: 'Cat', breed: 'Siamese', age: 3, gender: 'Male', color: 'Cream & Brown', status: 'adoption', location: 'Chattogram', description: 'Vocal and social Siamese cat who loves attention and playing with toys.' }
  ],
  care: [
    { record_id: 1, pet_id: 1, type: 'Vaccination', date: '2026-07-10', notes: 'Rabies booster', next_due_date: '2026-10-25' },
    { record_id: 2, pet_id: 2, type: 'Deworming', date: '2026-09-02', notes: 'Monthly tablet', next_due_date: '2026-10-20' },
    { record_id: 3, pet_id: 2, type: 'Vet Checkup', date: '2026-06-15', notes: 'All healthy', next_due_date: '2026-12-15' },
    { record_id: 4, pet_id: 1, type: 'Grooming', date: '2026-09-28', notes: 'Bath and nail trim', next_due_date: '2026-10-12' }
  ],
  notifs: [
    { notif_id: 1, type: 'match', message: 'A possible match was found for your lost pet Kiwi (91% similarity).', is_read: 0, created_at: '2026-10-17 09:12' },
    { notif_id: 2, type: 'adoption', message: 'Rahim Uddin sent an adoption request for Bruno.', is_read: 0, created_at: '2026-10-16 18:40' },
    { notif_id: 3, type: 'care', message: 'Luna\'s deworming is due in 3 days.', is_read: 0, created_at: '2026-10-16 08:00' },
    { notif_id: 4, type: 'system', message: 'Welcome to Pet Biometrics! Add your first pet to get started.', is_read: 1, created_at: '2026-10-10 12:00' }
  ],
  lost: [
    { report_id: 1, image: 'photos/site/lost1.jpg', reporter: 'Nadia Karim', location: 'Dhanmondi Lake, Dhaka', found_date: '2026-10-15', description: 'Small white and brown puppy found near the lake, wearing a red collar.', matched_pet: 'Daisy', match_score: 88, species: 'Dog' },
    { report_id: 2, image: 'photos/site/lost2.jpg', reporter: 'Tanvir Hasan', location: 'GEC Circle, Chattogram', found_date: '2026-10-14', description: 'Orange cat, very friendly, seems to be someone\'s pet.', matched_pet: 'Milo', match_score: 93, species: 'Cat' },
    { report_id: 3, image: 'photos/site/lost3.jpg', reporter: 'Sumaiya Akter', location: 'Zindabazar, Sylhet', found_date: '2026-10-12', description: 'Green parrot sitting on a tea stall roof.', matched_pet: null, match_score: null, species: 'Bird' }
  ],
  users: [
    { user_id: 1, name: 'Demo User', email: 'demo@petbio.com', phone: '01700000001', role: 'user', address: 'Dhaka', created_at: '2026-08-01' },
    { user_id: 2, name: 'Rahim Uddin', email: 'rahim@mail.com', phone: '01700000002', role: 'user', address: 'Chattogram', created_at: '2026-08-14' },
    { user_id: 3, name: 'Nadia Karim', email: 'nadia@mail.com', phone: '01700000003', role: 'user', address: 'Dhaka', created_at: '2026-09-02' },
    { user_id: 4, name: 'Tanvir Hasan', email: 'tanvir@mail.com', phone: '01700000004', role: 'user', address: 'Khulna', created_at: '2026-09-20' },
    { user_id: 5, name: 'Admin', email: 'admin@petbio.com', phone: '01700000005', role: 'admin', address: 'Dhaka', created_at: '2026-07-01' }
  ],
  requests: [
    { request_id: 1, pet: 'Bruno', requester: 'Rahim Uddin', message: 'I have a big garden and two kids who would love Bruno.', status: 'pending', date: '2026-10-16' },
    { request_id: 2, pet: 'Max', requester: 'Nadia Karim', message: 'Experienced with German Shepherds, very interested.', status: 'approved', date: '2026-10-13' },
  ]
};

/* ---------- Data helpers (localStorage = demo database) ---------- */
const Data = {
  pets() { let p = Store.get('pets'); if (!p) { p = DEMO.pets; Store.set('pets', p); } return p; },
  savePets(p) { Store.set('pets', p); },
  care() { let c = Store.get('care'); if (!c) { c = DEMO.care; Store.set('care', c); } return c; },
  saveCare(c) { Store.set('care', c); },
  notifs() { let n = Store.get('notifs'); if (!n) { n = DEMO.notifs; Store.set('notifs', n); } return n; },
  saveNotifs(n) { Store.set('notifs', n); },
  pet(id) { return this.pets().find(p => p.pet_id == id); }
};

/* ---------- API wrapper (used when USE_DEMO = false) ---------- */
async function api(path, { method = 'GET', body, form } = {}) {
  if (CONFIG.USE_DEMO) return null;
  const opt = { method, credentials: 'include', headers: {} };
  if (form) opt.body = form;
  else if (body) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch(CONFIG.API_BASE + path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message || 'Request failed');
  return j;
}

/* ---------- Auth ---------- */
const getUser = () => Store.get('user', null);
const setUser = u => Store.set('user', u);
function logout() { Store.del('user'); location.href = 'index.html'; }
function requireLogin() {
  if (!getUser()) { location.href = 'register.html?tab=login&next=' + encodeURIComponent(location.pathname.split('/').pop()); return false; }
  return true;
}

/* ---------- UI helpers ---------- */
function toast(msg, type = '') {
  let box = $('.toasts');
  if (!box) { box = document.createElement('div'); box.className = 'toasts'; document.body.appendChild(box); }
  const t = document.createElement('div');
  t.className = 'toast ' + type; t.textContent = msg; box.appendChild(t);
  setTimeout(() => t.remove(), 3600);
}
const openModal = id => $('#' + id).classList.add('open');
const closeModal = id => $('#' + id).classList.remove('open');
const fmtDate = d => d ? new Date(d.replace(' ', 'T')).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '-';
const daysUntil = d => Math.ceil((new Date(d) - new Date('2026-10-17')) / 864e5);
/* Photos: window.PHOTOS = { pet_id: [urls...] } (photos.js) or p.images / p.cover_image from the API */
const petImgs = p => (p.images && p.images.length ? p.images.map(i => i.image_path || i) : (window.PHOTOS || {})[p.pet_id] || Store.get('pimgs', {})[p.pet_id] || (p.cover_image ? [p.cover_image] : []));
const thumbHTML = (p, extra = '') => { const im = petImgs(p)[0]; return im ? `<img src="${esc(im)}" alt="${esc(p.name)}" loading="lazy" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover" onerror="this.remove()">${extra}` : `${EMOJI[p.species] || '🐾'}${extra}`; };
/* Resize an uploaded File to a small data-URL (so demo mode can keep real user photos in localStorage) */
const fileToDataURL = (f, max = 700) => new Promise(res => { const r = new FileReader(); r.onload = () => { const im = new Image(); im.onload = () => { const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = im.width * k; c.height = im.height * k; c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', .8)); }; im.onerror = () => res(null); im.src = r.result; }; r.onerror = () => res(null); r.readAsDataURL(f); });
const grad = id => GRAD[(id - 1) % GRAD.length];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function statusBadge(s) {
  const m = { adoption: ['Available', 'b-ok'], owned: ['With owner', 'b-info'], lost: ['Lost', 'b-danger'], adopted: ['Adopted', 'b-gray'], pending: ['Pending', 'b-warn'], approved: ['Approved', 'b-ok'], rejected: ['Rejected', 'b-danger'], active: ['Active', 'b-ok'] };
  const [t, c] = m[s] || [s, 'b-gray'];
  return `<span class="badge ${c}">${t}</span>`;
}

function petCard(p) {
  return `<a class="pet-card card" href="pet-details.html?id=${p.pet_id}">
    <div class="pet-thumb" style="background:${grad(p.pet_id)}">${thumbHTML(p, statusBadge(p.status).replace('<span', '<span style="position:absolute;z-index:1"'))}</div>
    <div class="pet-body"><h3>${esc(p.name)}</h3><p class="muted">${esc(p.breed)} • ${p.age} yr${p.age > 1 ? 's' : ''}</p>
    <div class="chips"><span class="chip">${esc(p.gender)}</span><span class="chip">📍 ${esc(p.location || '—')}</span><span class="chip">${esc(p.color)}</span></div></div></a>`;
}

/* Multi-photo uploader with previews. Returns { files() } */
function setupDropzone(zone, input, preview, { multiple = true, max = 6 } = {}) {
  let files = [];
  const render = () => {
    preview.innerHTML = '';
    files.forEach((f, i) => {
      const d = document.createElement('div'); d.className = 'prev';
      d.innerHTML = `<img src="${URL.createObjectURL(f)}" alt=""><button type="button" title="Remove">✕</button>${i === 0 && multiple ? '<span class="pri">Main</span>' : ''}`;
      d.querySelector('button').onclick = e => { e.stopPropagation(); files.splice(i, 1); render(); zone.dispatchEvent(new Event('change')); };
      preview.appendChild(d);
    });
  };
  const add = list => {
    [...list].filter(f => f.type.startsWith('image/')).forEach(f => {
      if (!multiple) files = [f]; else if (files.length < max) files.push(f); else toast('Maximum ' + max + ' photos allowed', 'err');
    });
    render(); zone.dispatchEvent(new Event('change'));
  };
  zone.onclick = () => input.click();
  input.onchange = () => { add(input.files); input.value = ''; };
  zone.ondragover = e => { e.preventDefault(); zone.classList.add('drag'); };
  zone.ondragleave = () => zone.classList.remove('drag');
  zone.ondrop = e => { e.preventDefault(); zone.classList.remove('drag'); add(e.dataTransfer.files); };
  return { files: () => files };
}

function tabs(container) {
  const btns = $$('.tab', container), panes = $$('[data-pane]', container.parentElement);
  btns.forEach(b => b.onclick = () => {
    btns.forEach(x => x.classList.toggle('active', x === b));
    panes.forEach(p => p.classList.toggle('hidden', p.dataset.pane !== b.dataset.tab));
  });
}

/* ---------- Layout (navbar + footer) ---------- */
function mountLayout() {
  const page = document.body.dataset.page || '';
  const user = getUser();
  const unread = Data.notifs().filter(n => !n.is_read).length;
  const link = (href, label, key) => `<a href="${href}" class="${page === key ? 'active' : ''}">${label}</a>`;
  const nav = $('#nav');
  if (nav) nav.innerHTML = `<header class="nav"><div class="container nav-inner">
    <a href="index.html" class="logo"><i>🐾</i><span>Pet<b>Bio</b>metrics</span></a>
    <button class="nav-toggle" onclick="$('.nav-links').classList.toggle('open')">☰</button>
    <nav class="nav-links">
      ${link('index.html', 'Home', 'home')}${link('adoption.html', 'Adopt', 'adoption')}${link('find-my-pet.html', 'Find My Pet', 'find')}
      ${link('lost-found.html', 'Lost &amp; Found', 'lost')}${link('care-tracker.html', 'Pet Care', 'care')}
      ${user ? link('dashboard.html', 'Dashboard', 'dashboard') + `<a href="notifications.html" class="${page === 'notif' ? 'active' : ''}">🔔${unread ? `<span class="bell-count">${unread}</span>` : ''}</a>` +
        (user.role === 'admin' ? link('admin.html', 'Admin', 'admin') : '') + `<a href="#" onclick="logout();return false" class="btn btn-ghost btn-sm" style="margin-left:6px">Logout</a>`
        : `<a href="register.html?tab=login" class="btn btn-ghost btn-sm" style="margin-left:6px">Login</a><a href="register.html" class="btn btn-primary btn-sm">Sign up</a>`}
    </nav></div></header>`;
  const f = $('#footer');
  if (f) f.innerHTML = `<footer class="footer"><div class="container"><div class="footer-grid">
    <div><a href="index.html" class="logo" style="color:#fff"><i>🐾</i><span>Pet<b>Bio</b>metrics</span></a>
    <p style="margin-top:14px;max-width:300px">A unique identity for every pet. Register, care for, adopt and reunite pets with smart biometric matching.</p></div>
    <div><h4>Explore</h4><a href="adoption.html">Adopt a pet</a><a href="find-my-pet.html">Find my pet</a><a href="lost-found.html">Lost &amp; found</a></div>
    <div><h4>My Account</h4><a href="dashboard.html">Dashboard</a><a href="pet-form.html">Add a pet</a><a href="care-tracker.html">Care tracker</a></div>
    <div><h4>Support</h4><a href="notifications.html">Notifications</a><a href="register.html?tab=login">Login</a><a href="admin.html">Admin panel</a></div>
    </div><div class="copy">© 2026 Pet Biometrics. Made with ❤️ for pets.</div></div></footer>`;
  $$('.modal-bg').forEach(m => m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); }));
}
document.addEventListener('DOMContentLoaded', mountLayout);