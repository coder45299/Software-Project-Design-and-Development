window.PHOTOS = {
 "1": [
  "photos/1/01.jpg",
  "photos/1/02.jpg",
  "photos/1/03.jpg",
  "photos/1/04.jpg",
  "photos/1/05.jpg",
  "photos/1/06.jpg",
  "photos/1/07.jpg",
  "photos/1/08.jpg",
  "photos/1/09.jpg",
  "photos/1/10.jpg"
 ],
 "2": [
  "photos/2/01.jpg",
  "photos/2/02.jpg",
  "photos/2/03.jpg",
  "photos/2/04.jpg",
  "photos/2/05.jpg",
  "photos/2/06.jpg",
  "photos/2/07.jpg",
  "photos/2/08.jpg",
  "photos/2/09.jpg",
  "photos/2/10.jpg"
 ],
 "3": [
  "photos/3/01.jpg",
  "photos/3/02.jpg",
  "photos/3/03.jpg",
  "photos/3/04.jpg",
  "photos/3/05.jpg",
  "photos/3/06.jpg",
  "photos/3/07.jpg",
  "photos/3/08.jpg",
  "photos/3/09.jpg",
  "photos/3/10.jpg"
 ],
 "4": [
  "photos/4/01.jpg",
  "photos/4/02.jpg",
  "photos/4/03.jpg",
  "photos/4/04.jpg",
  "photos/4/05.jpg",
  "photos/4/06.jpg",
  "photos/4/07.jpg",
  "photos/4/08.jpg",
  "photos/4/09.jpg",
  "photos/4/10.jpg"
 ],
 "6": [
  "photos/6/01.jpg",
  "photos/6/02.jpg",
  "photos/6/03.jpg",
  "photos/6/04.jpg",
  "photos/6/05.jpg",
  "photos/6/06.jpg",
  "photos/6/07.jpg",
  "photos/6/08.jpg",
  "photos/6/09.jpg",
  "photos/6/10.jpg"
 ],
 "7": [
  "photos/7/01.jpg",
  "photos/7/02.jpg",
  "photos/7/03.jpg",
  "photos/7/04.jpg",
  "photos/7/05.jpg",
  "photos/7/06.jpg",
  "photos/7/07.jpg",
  "photos/7/08.jpg",
  "photos/7/09.jpg",
  "photos/7/10.jpg"
 ],
 "8": [
  "photos/8/01.jpg",
  "photos/8/02.jpg",
  "photos/8/03.jpg",
  "photos/8/04.jpg",
  "photos/8/05.jpg",
  "photos/8/06.jpg",
  "photos/8/07.jpg",
  "photos/8/08.jpg",
  "photos/8/09.jpg",
  "photos/8/10.jpg"
 ]
};
